# Campus Club Management System


## Project Description

Campus Club Management System is a Spring Boot and MongoDB based backend application used to manage college clubs, students, and events.


## Features

- Student Management
- Club Management
- Event Management
- CRUD Operations
- REST APIs
- MongoDB Database Integration
- Swagger API Documentation


## Tech Stack

Backend:
- Java
- Spring Boot

Database:
- MongoDB

Tools:
- Maven
- Postman
- Swagger UI


## API Modules

### Students

POST
/students

GET
/students

PUT
/students/{id}

DELETE
/students/{id}


### Clubs

POST
/clubs

GET
/clubs

PUT
/clubs/{id}

DELETE
/clubs/{id}


### Events

POST
/events

GET
/events

PUT
/events/{id}

DELETE
/events/{id}


## How to Run

1. Start MongoDB

2. Open project folder

3. Run:

.\mvnw.cmd spring-boot:run


4. Open Swagger:

http://localhost:8081/swagger-ui/index.html


## Database

MongoDB Database:

CampusClubDB