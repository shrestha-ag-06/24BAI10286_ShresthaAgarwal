package com.campusclub.management;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CampusClubManagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(CampusClubManagementApplication.class, args);
	}

}
