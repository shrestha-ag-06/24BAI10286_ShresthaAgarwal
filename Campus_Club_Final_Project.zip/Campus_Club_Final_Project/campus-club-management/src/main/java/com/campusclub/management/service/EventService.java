package com.campusclub.management.service;

import com.campusclub.management.model.Event;
import com.campusclub.management.repository.EventRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class EventService {
    private final EventRepository repository;
    public EventService(EventRepository repository){
        this.repository = repository;
    }

    public Event addEvent(Event event){
        return repository.save(event);
    }

    public List<Event> getAllEvents(){
        return repository.findAll();
    }

    public Event updateEvent(String id, Event event){
        event.setId(id);
        return repository.save(event);
    }

    public void deleteEvent(String id){
        repository.deleteById(id);
    }

}
