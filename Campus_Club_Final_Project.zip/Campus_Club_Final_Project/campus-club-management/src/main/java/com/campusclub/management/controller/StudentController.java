package com.campusclub.management.controller;

import com.campusclub.management.model.Student;
import com.campusclub.management.service.StudentService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/students")
public class StudentController {

    private final StudentService service;

    public StudentController(StudentService service) {
        this.service = service;
    }

    @PostMapping
    public Student addStudent(@RequestBody Student student) {
        return service.addStudent(student);
    }

    @GetMapping
    public List<Student> getStudents() {
        return service.getAllStudents();
    }

    @PutMapping("/{id}")
    public Student updateStudent(
        @PathVariable String id,
        @RequestBody Student student){
            return service.updateStudent(id, student);
    }

    @DeleteMapping("/{id}")
    public String deleteStudent(
        @PathVariable String id){
            service.deleteStudent(id);
            return "Student deleted successfully";
    }
}