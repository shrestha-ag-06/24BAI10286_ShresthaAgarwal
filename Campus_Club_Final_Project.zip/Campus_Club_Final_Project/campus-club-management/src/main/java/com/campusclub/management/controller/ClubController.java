package com.campusclub.management.controller;

import com.campusclub.management.model.Club;
import com.campusclub.management.service.ClubService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/clubs")
public class ClubController {

    private final ClubService service;

    public ClubController(ClubService service) {
        this.service = service;
    }

    // Add club
    @PostMapping
    public Club addClub(@RequestBody Club club) {
        return service.addClub(club);
    }

    // Get all clubs
    @GetMapping
    public List<Club> getAllClubs() {
        return service.getAllClubs();
    }

    @PutMapping("/{id}")
    public Club updateClub(
        @PathVariable String id,
        @RequestBody Club club){
            return service.updateClub(id, club);
    }

    @DeleteMapping("/{id}")
    public String deleteClub(@PathVariable String id){
        service.deleteClub(id);
        return "Club deleted successfully";
    }
}