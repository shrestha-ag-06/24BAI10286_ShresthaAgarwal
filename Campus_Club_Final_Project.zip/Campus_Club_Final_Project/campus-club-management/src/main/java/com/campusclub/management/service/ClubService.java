package com.campusclub.management.service;

import com.campusclub.management.model.Club;
import com.campusclub.management.repository.ClubRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ClubService {

    private final ClubRepository repository;

    public ClubService(ClubRepository repository) {
        this.repository = repository;
    }

    // Add club
    public Club addClub(Club club) {
        return repository.save(club);
    }

    // Get all clubs
    public List<Club> getAllClubs() {
        return repository.findAll();
    }

    public Club updateClub(String id, Club club){
        club.setId(id);
        return repository.save(club);
    }

    public void deleteClub(String id){
        repository.deleteById(id);
    }
}
