package com.campusclub.management.service;

import com.campusclub.management.model.Student;
import com.campusclub.management.repository.StudentRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class StudentService {

    private final StudentRepository repository;

    public StudentService(StudentRepository repository) {
        this.repository = repository;
    }

    public Student addStudent(Student student) {
        return repository.save(student);
    }

    public List<Student> getAllStudents() {
        return repository.findAll();
    }

    public Student updateStudent(String id, Student student){
        student.setId(id);
        return repository.save(student);
    }


    public void deleteStudent(String id){
        repository.deleteById(id);
    }
    
}
