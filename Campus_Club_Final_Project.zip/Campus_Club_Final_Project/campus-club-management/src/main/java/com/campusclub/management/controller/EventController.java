package com.campusclub.management.controller;


import com.campusclub.management.model.Event;
import com.campusclub.management.service.EventService;

import org.springframework.web.bind.annotation.*;

import java.util.List;


@RestController
@RequestMapping("/events")
public class EventController {
    private final EventService service;
    public EventController(EventService service){
        this.service = service;
    }

    @PostMapping
    public Event addEvent(@RequestBody Event event){
        return service.addEvent(event);
    }

    @GetMapping
    public List<Event> getAllEvents(){
        return service.getAllEvents();
    }

    @PutMapping("/{id}")
    public Event updateEvent(
        @PathVariable String id,
        @RequestBody Event event){
    return service.updateEvent(id,event);
    }

    @DeleteMapping("/{id}")
    public String deleteEvent(@PathVariable String id){
        service.deleteEvent(id);
        return "Event deleted successfully";
    }

}
