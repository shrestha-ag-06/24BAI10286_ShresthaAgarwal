package com.campusclub.management.config;
import org.springframework.context.annotation.Configuration;
@Configuration
public class MongoConfig {
}